import React, { useState } from 'react';
import { FaChevronDown } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import DashboardIcon from '../../Assests/Dashboard/dashboard.svg';
import ShoppingCartIcon from '../../Assests/Dashboard/orders.svg';
import CategoryIcon from '../../Assests/Dashboard/category.svg';
import CouponIcon from '../../Assests/Dashboard/coupon1.svg';
import AttributesIcon from '../../Assests/Dashboard/attributesadmin.svg';
import PurchaseIcon from '../../Assests/Dashboard/attributes.svg';
import DataIcon from '../../Assests/Dashboard/importdata.svg';
import ProductIcon from '../../Assests/Dashboard/coupon.svg';
import VenderIcon from '../../Assests/Dashboard/vender.svg';
import TimesheetIcon from '../../Assests/Dashboard/timesheet.svg';
import StoreIcon from '../../Assests/Dashboard/store.svg';
import ReportIcon from '../../Assests/Dashboard/reporting.svg';





const SideMenu = () => {

  const [clickedItem, setClickedItem] = useState(null);
  const [isSmallScreen, setIsSmallScreen] = useState(window.innerWidth < 994);

  const handleItemClick = (id) => {
    setClickedItem((prevId) => (prevId === id ? null : id));
  };

  const handleMouseEnter = (event) => {
    event.target.style.fill = 'yellow';
  };

  const handleMouseLeave = (event) => {
    event.target.style.fill = '';
  };

  const toggleSidebar = () => {
    setIsSmallScreen(!isSmallScreen);
  };
return (
    <>
  <div className={`fixed top-20 left-0 w-72 ${isSmallScreen ? 'hidden' : ''}`} style={{ backgroundColor: 'black' }}>
        <div className='flex-1 text-white p-4 ml-5'>
          <div className=''>
            {menuItems.map((item) => (
              <div key={item.id} className='mb-4 text-base flex'>
                {item.dropdownItems ? (
                  <DropdownMenuItem item={item} />
                ) : (
                  <div
                    className={`flex items-center ${
                      clickedItem === item.id ? 'text-[#FFC400]' : 'text-gray-400 hover-text-yellow'
                    }`}
                  >
                    {item.icon}
                    <Link
                      onClick={() => handleItemClick(item.id)}
                      className='ml-2 menu-item text-[16px] Admin_std'
                      to={item.link}
                    >
                      {item.text}
                    </Link>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
         {/* Show only icons on small screens */}
         {isSmallScreen && (
        <div className='fixed top-20 left-0 w-16 h-16 bg-black text-white flex items-center justify-center cursor-pointer' onClick={toggleSidebar}>
          <svg fill='none' strokeLinecap='round' strokeLinejoin='round' strokeWidth='2' viewBox='0 0 24 24' stroke='currentColor' className='h-6 w-6'>
            <path d='M4 6h16M4 12h16m-7 6h7'></path>
          </svg>
        </div>
      )}
    </>
  );
};
const DropdownMenuItem = ({ item }) => {
  const [isDropdownOpen, setDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setDropdownOpen(!isDropdownOpen);
  };

        {/* Right Dashboard Menu */}
 


  return (
<div className='flex items-center'>
      {item.icon}
      <p className='ml-2 cursor-pointer menu-item text-gray-400 flex mb-2 ' onClick={toggleDropdown}>
        {item.text}
        <FaChevronDown className='ml-3 my-2' />
      </p>
      {isDropdownOpen && (
        <div className='ml-4 bg-white p-2'>
          {item.dropdownItems.map((dropdownItem) => (
            <p key={dropdownItem.id} className='flex items-center submenu-item text-gray-400'>
              {dropdownItem.text}
              <FaChevronDown className='ml-3 my-2' />
            </p>
          ))}
        </div>
      )}
    </div>
  );
}; 
// Define menu items with icons and text
<a href="/attributes">
<img
  src={AttributesIcon}
  alt="Attributes"
  className='h-6 w-6 mt-4 mb-4'
  onMouseEnter={(event) => {
    event.target.style.fill = 'yellow'; // Change to the desired hover color
  }}
  onMouseLeave={(event) => {
    event.target.style.fill = ''; // Reset to default color on mouse leave
  }}
/>
<span>Attributes</span>
</a>
const menuItems = [
   {
    id: 1,
    icon: <img src={DashboardIcon} alt="Dashboard" className="h-6 w-6 mt-4 mb-4 menu-item:hover "/>,
    
    text: 'Dashboard',
    link: '/dashboard',
  },
  {
    id: 2,
    icon: <img src={ShoppingCartIcon} alt="Order" className="h-6 w-6 mt-4 mb-4 menu-item:hover  " />,
    text: 'Order',
    link: '/order',
  },
  {
    id: 3,
    icon: <img src={CategoryIcon} alt="Category" className='h-6 w-6 mt-4 mb-4 menu-item:hover ' />,
    text: 'Category',
    link: '/category',
  },
  {
    id: 4,
    icon: <img src={PurchaseIcon} alt="Products" className='h-6 w-6 mt-4 mb-4' />,
    text: 'Products',
    link: '/products',
  },
  {
    id: 4,
    icon: <img src={AttributesIcon} alt="Attributes" className='h-6 w-6 mt-4 mb-4' />,
    text: 'Attributes',
    link: '/attributes',
  },
  {
    id: 6,
    icon: <img src={ProductIcon} alt="Purchase Data" className='h-6 w-6 mt-4 mb-4' />,
    text: 'Purchase Data',
    link: '/purchase-data',
  },
  {
    id: 7,
    icon: <img src={VenderIcon} alt="Import Data" className='h-6 w-6 mt-4 mb-4  ' />,
    text: 'Import Data',
    link: '/import-data',
  },
  {
    id: 4,
    icon: <img src={CouponIcon} alt="Coupons" className='h-6 w-6 mt-4 mb-4' />,
    text: 'Coupons',
    link: '/coupons',
  },
  {
    id: 9,
    icon: <img src={PurchaseIcon} alt="Vendors" className='h-6 w-6 mt-4 mb-4' />,
    text: 'Vendors',
    link: '/vendors',
  },
  {
    id: 10,
    icon: <img src={TimesheetIcon} alt="Timesheet" className='h-6 w-6 mt-4 mb-4' />,
    text: 'Timesheet',
    link: '/timesheet',
  },

  {
    id: 11,
   icon: <img src={StoreIcon} alt="store" className="h-6 w-6 mt-4 mb-4" />,
    text: 'Store Settings',
    className: 'flex items-center gap-2',
    dropdownItems: [
      { id: 61, text: 'Submenu 1', link: '/store-settings/submenu1' },
      { id: 62, text: 'Submenu 2', link: '/store-settings/submenu2' }
    ]
  },
  {
    id: 12,
   icon: <img src={ReportIcon} alt="Report" className="h-6 w-6 mt- mb-4" />,
    text: 'Reporting',
    className: 'flex items-center gap-2',
    dropdownItems: [
      { id: 61, text: 'Submenu 1', link: '/reporting/submenu1' },
      { id: 62, text: 'Submenu 2', link: '/reporting/submenu2' }
    ]
  }
];

export default SideMenu;
